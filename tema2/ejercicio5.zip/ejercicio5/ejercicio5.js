const num = prompt("Ingresa un número del 1 al 6:");

switch (num) {
  case "1":
    document.write("<h1>Encabezado 1</h1>");
    break;
  case "2":
    document.write("<h1>Encabezado 2</h1>");
    break;
  case "3":
    document.write("<h1>Encabezado 3</h1>");
    break;
  case "4":
    document.write("<h1>Encabezado 4</h1>");
    break;
  case "5":
    document.write("<h1>Encabezado 5</h1>");
    break;
  case "6":
    document.write("<h1>Encabezado 6</h1>");
    break;
  default:
    document.write("No existe ese tipo de encabezado");
    break;
}
