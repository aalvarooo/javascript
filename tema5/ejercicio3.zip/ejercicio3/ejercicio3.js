function Href(){
    document.getElementById('enlace').innerHTML=" Google"
    document.getElementById('enlace').href="http://www.google.com"
}